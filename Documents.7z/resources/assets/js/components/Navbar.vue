<template>
	<nav class="navbar navbar-expand-sm navbar-dark bg-info mb-2">
		<div class="container">
			<a href="#" class="navbar-brand"> Larticles</a>
		</div>
	</nav>
</template>